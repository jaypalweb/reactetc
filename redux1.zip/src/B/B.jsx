import "./B.css";
import React from "react";

function template() {
  return (
    <div className="b">
      <h1>{this.props.name}</h1>
    </div>
  );
};

export default template;
