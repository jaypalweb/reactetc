const initVal={
    'name':'',
    'run':0,
    'loc':''
}

export default initVal;