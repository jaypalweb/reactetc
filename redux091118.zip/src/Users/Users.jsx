import "./Users.css";
import React from "react";

function template() {
  return (
    <div className="users">
      <h1>Users</h1>
    </div>
  );
};

export default template;
