const initVal={
    'users':[],
    'posts':[]
}

export default initVal;