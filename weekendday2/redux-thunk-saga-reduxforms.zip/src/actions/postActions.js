import ServerCall from '../serivces/ServerCall';
const postActions=()=>{
    
    return (dispatch)=>{
        ServerCall.getData('https://jsonplaceholder.typicode.com/posts')
        .then((res)=>{
            dispatch({
                'type':'posts',
                'payload':res.data
            })
        })
        .catch(()=>{
            dispatch({
                'type':'posts',
                'payload':[]
            })
        });
    }
}


export default postActions;