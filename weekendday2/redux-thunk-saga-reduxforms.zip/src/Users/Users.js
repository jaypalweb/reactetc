import React    from "react";
import template from "./Users.jsx";
import ServerCall from '../serivces/ServerCall';
import {connect} from 'react-redux'

class Users extends React.Component {
  render() {
    return template.call(this);
  }

   async fnGetUser(){
     debugger;
    const res= await ServerCall.getData('https://jsonplaceholder.typicode.com/users')
    debugger;
    this.props.d({
      'type':'users',
      'payload':res.data
    })
  }
}
const mapDispatchToProps=(dispatch)=>{
     return {
        'd':dispatch
     }
}
export default connect(null,mapDispatchToProps)(Users);
