import "./Users.css";
import React from "react";

function template() {
  return (
    <div className="users">
      <input type='button' value="store users" onClick={this.fnGetUser.bind(this)}/>
    </div>
  );
};

export default template;
