import React from 'react';
const renderText=({name,type,id,input,meta:{touched,error}})=>{
     return <p>
             <input {...input} id={id} type={type} name={name} />
             {
                 touched && error && <span className="error">{error}</span>
             }
            </p>
}

export default renderText;