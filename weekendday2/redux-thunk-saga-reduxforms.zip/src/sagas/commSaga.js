import {takeLatest,call,put} from 'redux-saga/effects'
import ServerCall from '../serivces/ServerCall';
function* getComments(){
    debugger;
  const res=  yield call(ServerCall.getData,"https://jsonplaceholder.typicode.com/comments")
    debugger;
    yield put({
        'type':'comm',
        'payload':res.data
    })
}

function* insertComm(){

}

function* commSaga(){
    yield takeLatest('gc',getComments);
    yield takeLatest('ic',insertComm);
}

export default commSaga;