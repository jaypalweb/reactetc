import {all} from 'redux-saga/effects';
import commSaga from './commSaga';

function* rootSaga(){
    yield all([
        commSaga()
    ])
}

export default rootSaga;