import Diplay from "./Diplay";
export default Diplay;
