import React    from "react";
import template from "./Diplay.jsx";
import {reduxForm} from 'redux-form';
import loginValidation from '../validations/loginValidations';
class Diplay extends React.Component {
  render() {
    return template.call(this);
  }
  fnLogin(data){
    debugger;
  }
}

Diplay=reduxForm({
  'form':'loginForm',
  'validate':loginValidation
})(Diplay)

export default Diplay;
