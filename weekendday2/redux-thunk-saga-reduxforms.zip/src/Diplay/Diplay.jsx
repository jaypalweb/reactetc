import "./Diplay.css";
import React from "react";
import {Field} from 'redux-form';
import renderText from '../reduxFormComponents/renderText';
function template() {
  const {handleSubmit,invalid} =this.props;
  return (
    <div className="diplay">
      <h1>Login</h1>
      <form onSubmit={handleSubmit(this.fnLogin)}>
          <Field
           name="uid"
           type="text"
           id="uid"
           component={renderText}
          />
           <Field
           name="pwd"
           id="pwd"
           type="password"
           component={renderText}
          />
          <input type="submit" disabled={invalid} value="login" />
      </form>
    </div>
  );
};

export default template;
