import axios from 'axios';
class ServerCall{

    static getData(url){
        return axios.get(url);
    }
}

export default ServerCall;