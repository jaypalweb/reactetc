export const userInit={
    'u':[]
}

export const postsInit={
    'posts':[]
}


export const commInit={
    'comm':[]
}