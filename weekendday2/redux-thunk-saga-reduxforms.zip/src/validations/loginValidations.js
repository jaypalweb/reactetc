const loginValidation=(values)=>{
    let errors={};

    if(!values.uid){
        errors.uid="Please enter uid";
    }
    if(!values.pwd){
        errors.pwd="Please enter pwd";
    }

    return errors;

}

export default loginValidation;

