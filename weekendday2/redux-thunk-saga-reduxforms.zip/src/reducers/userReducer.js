import {userInit} from '../utils/init'
const userReducer=(state=userInit,actions)=>{
    switch(actions.type){
        case 'users':
           state={
               ...state,
               'u':actions.payload
           }
        break;
    }
    return state;
}

export default userReducer;