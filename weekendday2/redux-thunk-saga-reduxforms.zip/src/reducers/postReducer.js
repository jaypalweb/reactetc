import {postsInit} from '../utils/init'

const postReducer=(state=postsInit  ,actionData)=>{
      switch(actionData.type){
          case 'posts':
             state={
                 ...state,
                 'posts':actionData.payload
             }
          break;
      }
      return state;
}

export default postReducer;