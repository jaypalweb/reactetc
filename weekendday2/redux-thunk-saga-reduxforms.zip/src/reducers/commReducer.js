import {commInit} from '../utils/init'

const commReducer=(state=commInit  ,actionData)=>{
      switch(actionData.type){
          case 'comm':
             state={
                 ...state,
                 'comm':actionData.payload
             }
          break;
      }
      return state;
}

export default commReducer;