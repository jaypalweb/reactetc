import {combineReducers} from 'redux';
import userReducer from './userReducer';
import postReducer from './postReducer';
import commReducer from './commReducer';
import {reducer as form} from 'redux-form'
const rootReducer=combineReducers({userReducer,postReducer,form,commReducer,});
export default rootReducer;