import React    from "react";
import template from "./Posts.jsx";
import {connect} from 'react-redux';
import postActions from '../actions/postActions';
import {bindActionCreators} from 'redux'
class Posts extends React.Component {
  render() {
    return template.call(this);
  }

  fnGetPosts(){
    this.props.postActions();
  }
}
const mdp=(dispatch)=>{
  return {
    'postActions':bindActionCreators(postActions,dispatch)
  }
}
export default connect(null,mdp)(Posts);
