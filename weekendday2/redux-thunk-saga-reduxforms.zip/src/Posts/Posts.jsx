import "./Posts.css";
import React from "react";

function template() {
  return (
    <div className="posts">
       <input type="button" onClick={this.fnGetPosts.bind(this)} value="store posts" />
    </div>
  );
};

export default template;
