import React    from "react";
import template from "./Comm.jsx";
import store from '../store/store';
class Comm extends React.Component {
  render() {
    return template.call(this);
  }
  fnStoreComm(){
    debugger;
    store.dispatch({
      'type':'gc'
    })
  }
}

export default Comm;
