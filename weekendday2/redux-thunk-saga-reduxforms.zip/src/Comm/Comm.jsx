import "./Comm.css";
import React from "react";

function template() {
  return (
    <div className="comm">
      <input type="button" value="store comm" onClick={this.fnStoreComm.bind(this)} />
    </div>
  );
};

export default template;
