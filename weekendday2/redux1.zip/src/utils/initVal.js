const initVal={
    'name':'',
    'loc':''
}

export default initVal;