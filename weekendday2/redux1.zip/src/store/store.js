import {createStore,combineReducers,applyMiddleware} from 'redux';
import perReducer from '../reducers/perInfoReducer';
import logger from 'redux-logger'
const s=createStore(combineReducers({perReducer}),applyMiddleware(logger));
export default s;