import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import A from './A/A';
import B from './B/B';
import C from './C/C';
class App extends Component {
  render() {
    return (
      <div className="App">
         <A />
         <B />
         <C />
      </div>
    );
  }
}

export default App;
