import "./C.css";
import React from "react";

function template() {
  return (
    <div className="c">
      <h1>{this.props.n}</h1>
      <h1>{this.props.l}</h1>
    </div>
  );
};

export default template;
