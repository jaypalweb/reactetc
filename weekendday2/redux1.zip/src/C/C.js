import React    from "react";
import template from "./C.jsx";
import {connect} from 'react-redux';
class C extends React.Component {
  render() {
    return template.call(this);
  }
}

const f1=(state)=>{
  return {
     'n':state.perReducer.name,
     'l':state.perReducer.loc
  }
}


export default connect(f1)(C)
