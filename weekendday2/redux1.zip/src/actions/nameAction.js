//import s from '../store/store';
const nameAction=(n,d)=>{
   debugger;
    d({
        'type':'un',
        'payload':n
    })
}

export default nameAction;