import s from '../store/store';
const locAction=(loc)=>{
    s.dispatch({
        'type':'ul',
        'payload':loc
    })
}

export default locAction;