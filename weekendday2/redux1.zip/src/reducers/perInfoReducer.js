import initVal from '../utils/initVal'
const perReducer=(state=initVal,action)=>{
      switch(action.type){
          case 'un':
            state={
                ...state,
                'name':action.payload
            }
          break;
          case 'ul':
          state={
            ...state,
            'loc':action.payload
             }
          break;

      }
      return state;
}

export default perReducer;