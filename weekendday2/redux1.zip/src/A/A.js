import React    from "react";
import template from "./A.jsx";
import nameAction from '../actions/nameAction';
import {connect} from 'react-redux'
class A extends React.Component {
  fnSendName(){
    this.props.f(this.refs.name.value);
   // nameAction(this.refs.name.value,this.props.d);
  }
  render() {
    return template.call(this);
  }
}
const f=(dispatch)=>{
  debugger;
  return{
     'f':(name)=>{
       debugger;
      nameAction(name,dispatch)
     }
  }
}
export default connect(null,f)(A)
