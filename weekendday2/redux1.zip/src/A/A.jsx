import "./A.css";
import React from "react";

function template() {
  return (
    <div className="a">
      <p>
        <input ref="name" /><input type="button" value="store name" onClick={this.fnSendName.bind(this)}/>
      </p>
    </div>
  );
};

export default template;
