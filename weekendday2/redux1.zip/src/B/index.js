import B from "./B";
export default B;
