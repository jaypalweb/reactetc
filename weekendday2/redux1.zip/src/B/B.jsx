import "./B.css";
import React from "react";

function template() {
  return (
    <div className="b">
      <p>
        <input ref="loc" /><input type="button" value="store log" onClick={this.fnSendLoc.bind(this)}/>
      </p>
    </div>
  );
};

export default template;
