import React    from "react";
import template from "./B.jsx";
import locAction from '../actions/locAction';
class B extends React.Component {
  fnSendLoc(){
    locAction(this.refs.loc.value);
  }
  render() {
    return template.call(this);
  }
}

export default B;
