import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
      <h1>Footer</h1>
    </div>
  );
};

export default template;
