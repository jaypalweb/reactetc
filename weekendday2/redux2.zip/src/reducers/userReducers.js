import initVal from '../utils/initVal';

const userReducer=(state=initVal,actionData)=>{
     switch(actionData.type){
         case 'users':
             state={
                 ...state,
                 'users':actionData.payload
             }
         break;
     }
     return state;
}

export default userReducer;