import "./DispUsers.css";
import React from "react";

function template() {
  return (
    <div className="disp-users">
      <h1>users</h1>
      {
        this.props.users.map((o)=>{
            return <div>
                      <h1>{o.id}</h1>
                      <h2>{o.name}</h2>
                      <h4>{o.email}</h4>
                      <hr/>
                   </div>
        })
      }
    </div>
  );
};

export default template;
