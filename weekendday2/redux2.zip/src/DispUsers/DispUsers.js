import React    from "react";
import template from "./DispUsers.jsx";
import {connect} from 'react-redux';
class DispUsers extends React.Component {
  render() {
    return template.call(this);
  }
}

const mapStatetoProps=(state)=>{
  debugger;
  return {
    'users':state.userReducer.users
  }
}

export default connect(mapStatetoProps)(DispUsers);
