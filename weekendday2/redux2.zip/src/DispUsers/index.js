import DispUsers from "./DispUsers";
export default DispUsers;
