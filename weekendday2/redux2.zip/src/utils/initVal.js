const initVal={
    'users':[],
    'posts':[],
    'comm':[]
}

export default initVal;