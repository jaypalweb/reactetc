import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header">
      <h1>Header</h1>
    </div>
  );
};

export default template;
