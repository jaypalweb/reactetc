//import axios from 'axios';
import ServerCall from '../services/serverCall';
// const userAction=(d)=>{
//     serverCall.get('https://jsonplaceholder.typicode.com/users')
//     // axios.get('https://jsonplaceholder.typicode.com/users')
//     .then((res)=>{
//         debugger;
//         d({
//             'type':'users',
//             'payload':res.data
//         })
//     })
//     .catch((err)=>{
//         d({
//             'type':'users',
//             'payload':[]
//         })
//     })
// }

const userAction = () => {
    return (dispatch) => {
        debugger;
        ServerCall.get('https://jsonplaceholder.typicode.com/users')
            .then((res) => {
                debugger;
                dispatch({
                    'type': 'users',
                    'payload': res.data
                })
            })
            .catch((err) => {
                dispatch({
                    'type': 'users',
                    'payload': []
                })
            })

    }
}
export default userAction;