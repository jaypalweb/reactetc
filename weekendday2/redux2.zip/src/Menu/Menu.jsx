import "./Menu.css";
import React from "react";
import Users from '../Users/Users';
import DispUsers from '../DispUsers/DispUsers'
import {HashRouter,Route} from 'react-router-dom'
function template() {
  return (
    <div className="menu">
       <HashRouter>
          <div>
              <div>
                  <a href="#/users" >Users</a>
                  <a href="#/showUsers">Show users</a>
              </div>
              <Route path="/" exact component={Users}/>
              <Route path="/users" exact component={Users}/>
              <Route path="/showUsers" exact component={DispUsers}/>
              
          </div>
       </HashRouter>
    </div>
  );
};

export default template;
