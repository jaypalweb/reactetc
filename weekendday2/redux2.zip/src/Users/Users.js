import React    from "react";
import template from "./Users.jsx";
import userAction from '../actions/userAction';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux'
class Users extends React.Component {
  fnGetusers(){
    debugger;
   this.props.userAction();
  }
  render() {
    return template.call(this);
  }
}

const mapDispatchToProps=(dispatch)=>{
    return {
        'userAction':bindActionCreators(userAction,dispatch)
    }
}

export default connect(null,mapDispatchToProps)(Users);
