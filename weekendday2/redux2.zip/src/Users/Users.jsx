import "./Users.css";
import React from "react";

function template() {
  return (
    <div className="users">
       <input type="button" value="get users" onClick={this.fnGetusers.bind(this)}/>
    </div>
  );
};

export default template;
