import axios from 'axios'
class ServerCall{
   static get(url){
       return axios.get(url);
    }
}

export default ServerCall;