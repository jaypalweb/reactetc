import React    from "react";
import template from "./List.jsx";

class List extends React.Component {
  render() {
    return template.call(this);
  }
}

export default List;
