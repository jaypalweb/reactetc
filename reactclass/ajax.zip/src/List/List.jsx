import "./List.css";
import React from "react";

function template() {
  return (
    <div className="list">
      <h1>{this.props.heading}</h1>
      {
        this.props.d && this.props.d.map((o)=>{
             return <div><ul>
                       {
                         this.props.k && this.props.k.map((v)=>{
                              return <li>{o[v]}</li>
                         })
                       }
                    </ul>
                    <hr/>
                    </div>

        })
      }
    </div>
  );
};

export default template;
