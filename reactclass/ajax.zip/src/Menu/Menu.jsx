import "./Menu.css";
import React from "react";
import {HashRouter,Route} from 'react-router-dom'; 
import Users from '../Users/Users';
import Posts from '../Posts/Posts';
import Photos from '../Photos/Photos';
function template() {
  return (
    <div>
      <HashRouter>
         <div>
              <div className="menu">
                  <a href="#/users">USERS</a>
                  <a href="#/posts">POSTS</a>
                  <a href="#/photos">PHOTOS</a>
              </div>
              <Route  path="/" exact component={Users} />
              <Route path="/users" component={Users} />
              <Route path="/posts" component={Posts} />
              <Route path="/photos" component={Photos} />
         </div>
      </HashRouter>
    </div>
  );
};

export default template;
