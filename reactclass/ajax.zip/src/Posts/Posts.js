import React    from "react";
import template from "./Posts.jsx";
import $ from 'jquery';
class Posts extends React.Component {
  constructor(){
    super();
    this.state={
      'data':[],
      'keys':['id','title','body']
    }
  }
  componentWillMount(){
     $.get('https://jsonplaceholder.typicode.com/posts')
     .then((res)=>{
        debugger;
        this.setState({
          'data':res
        })
     },(res)=>{
        debugger;
        this.setState({
          'data':[]
        })
     })
  }
  render() {
    return template.call(this);
  }
}

export default Posts;
