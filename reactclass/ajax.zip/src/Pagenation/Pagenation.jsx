import "./Pagenation.css";
import React from "react";

function template() {
  return (
    <div className="pagenation">
     <div>
       <input type="text" ref="pageNo"  /><input type="button" value="Go To" onClick={this.fnGoTo.bind(this)} />
     </div>
     <div>
        <input type="button" value="pre" onClick={this.fnPre.bind(this)} disabled={this.state.currPage == 1}/>
        <span>{this.state.currPage}</span>
        <input type="button" value="next" onClick={this.fnNext.bind(this)} disabled={this.state.currPage == this.state.totalPages}/>
     </div>
     <div>
       <span>No of Pages:{this.state.totalPages}</span>
     </div>
    </div>
  );
};

export default template;
