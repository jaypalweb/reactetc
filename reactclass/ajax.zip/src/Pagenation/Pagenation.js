import React from "react";
import template from "./Pagenation.jsx";

class Pagenation extends React.Component {
  constructor() {
    super();
    this.state = {
      'perPage': 50,
      'totalPages': 0,
      'currPage': 1
    }
    this.fnPrepareData = this.fnPrepareData.bind(this);
  }
  fnGoTo() {
    this.setState({
      'currPage': this.refs.pageNo.value
    })
    setTimeout(function () {
      this.fnPrepareData();
    }.bind(this), 500);
  }

  fnPre() {
    this.refs.pageNo.value='';
    this.setState({
      'currPage': --this.state.currPage
    })
    this.fnPrepareData();
  }

  fnNext() {
    this.refs.pageNo.value='';
    this.setState({
      'currPage': ++this.state.currPage
    })
    this.fnPrepareData();
  }

  fnPrepareData() {
    let end = this.state.currPage * this.state.perPage;
    let start = end - this.state.perPage;
    this.props.fsd(this.props.data.slice(start, end))
  }



  componentWillReceiveProps() {
    setTimeout(function () {
      this.setState({
        'totalPages': this.props.data.length / this.state.perPage
      })
    }.bind(this), 1000);
  }
  render() {
    return template.call(this);
  }
}

export default Pagenation;
