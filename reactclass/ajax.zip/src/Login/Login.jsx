import "./Login.css";
import React from "react";

function template() {
  return (
    <div className="login">
      <h1>Login</h1>
      <p><input type="text" onChange={this.fnChange.bind(this,'userName')} /></p>
      <p><input type="text"  onChange={this.fnChange.bind(this,'pwd')} /></p>
      <p><input type="button" value="login" disabled={!this.state.isValid}/></p>
    </div>
  );
};

export default template;
