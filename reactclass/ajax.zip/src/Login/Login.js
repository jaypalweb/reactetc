import React    from "react";
import template from "./Login.jsx";

class Login extends React.Component {
  constructor(){
    super();
    this.state={
      'isValid':false,
      'loginData':{}
    }


    this.fnValidate=this.fnValidate.bind(this);
  }
  fnChange(ft,e){
     debugger;
     this.setState({
      'loginData':{
        ...this.state.loginData,
        [ft]:e.target.value
      }
     },this.fnValidate)
    
  }

  fnValidate(){
    debugger;
      if(this.state.loginData.userName  && this.state.loginData.pwd ){
        this.setState({
          'isValid':true
        })
      }
      if(!this.state.loginData.userName  || !this.state.loginData.pwd ){
        this.setState({
          'isValid':false
        })
      }
  }
  render() {
    return template.call(this);
  }
}

export default Login;
