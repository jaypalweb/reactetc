import Photos from "./Photos";
export default Photos;
