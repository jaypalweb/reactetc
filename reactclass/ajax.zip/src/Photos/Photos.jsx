import "./Photos.css";
import React from "react";
import Pagination from '../Pagenation/Pagenation'
function template() {

  
  return (
    <div>
       <input type="button" value="get photos" onClick={this.fnGetPhotos.bind(this)} />
       {
         this.state.data && this.state.data.map((o)=>{
              return <div className="photo">
                         <p><b>{o.id}</b></p>
                         <p><b>{o.title}</b></p>
                         <p><b>{o.url}</b></p>
                         <img src={o.thumbnailUrl} />
                     </div>
         })
       }
       {
         this.state.totalRecords.length > 0 && 
         <Pagination data={this.state.totalRecords} fsd={this.fnGetPagenationData}  />
       }
    </div>
  );
};

export default template;
