import React    from "react";
import template from "./Photos.jsx";
import axios from 'axios';
class Photos extends React.Component {
  constructor(){
    super();
    this.state={
      'data':[],
      'totalRecords':[]
    }
    this.fnGetPagenationData=this.fnGetPagenationData.bind(this);
  }
  fnGetPagenationData(d){
        debugger;
        this.setState({
          'data':d
        })
  }
  fnGetPhotos(){
     axios.get('https://jsonplaceholder.typicode.com/photos')
     .then((res)=>{
      debugger;
      this.setState({
        'data':res.data.slice(0,50),
        'totalRecords':res.data
      })
     })
     .catch((err)=>{
      debugger;
      this.setState({
        'data':[]
      })
     })
  }
  render() {
    return template.call(this);
  }
}

export default Photos;
