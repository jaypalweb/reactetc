import React from "react";
import template from "./Users.jsx";

class Users extends React.Component {
  constructor(){
    super();
    this.state={
      'header':['ID','NAME','PHONE','WEBSITE'],
      'k':['id','name','phone','website'],
      'd':[]
    }
  }
  componentWillMount() {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(json => {
        debugger;
        this.setState({
          'd':json
        })
      })
  }
  render() {
    return template.call(this);
  }
}

export default Users;
