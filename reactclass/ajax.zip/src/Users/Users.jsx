import "./Users.css";
import React from "react";
import Table from '../table/table';

function template() {
  return (
    <div className="users">
      <h1>Users</h1>
      {
      this.state.d.length != 0 && 
      <Table h={this.state.header}   d={this.state.d}  k={this.state.k} />
      }
      </div>
  );
};

export default template;
