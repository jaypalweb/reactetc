import React    from "react";
import template from "./Services.jsx";

class Services extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Services;
