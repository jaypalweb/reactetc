import "./About.css";
import React from "react";

function template() {
  return (
    <div className="about">
      <h1>About</h1>
    </div>
  );
};

export default template;
