import "./Menu.css";
import React from "react";
import {HashRouter,Route,BrowserRouter,Link} from 'react-router-dom'
import Home from '../Home/Home'; 
import About from '../About/About';
import Services from '../Services/Services';
import Contact from '../Contact/Contact';
function template() {
  return (
    <div>
      <BrowserRouter>
         <div>
              <div className="menu">
                   <li><Link to="/home" >Home</Link></li>
                   <li><Link to="/about" >about</Link></li>
                   <li><Link to="/service" >service</Link></li>
                   <li><Link to="/contact" >contact</Link></li>
              </div>
            <Route path="/" exact component={Home} />
            <Route path="/home" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/contact" component={Contact} />
            <Route path="/service" component={Services} />

         </div>
      </BrowserRouter>
      {/* <HashRouter>
        <div>
            <div className="menu">
                <a href="#/home">HOME</a>
                <a href="#/about">ABOUT</a>
                <a href="#/contact">CONTACT</a>
                <a href="#/service">SERVICE</a>
            </div>
            <Route path="/" exact component={Home} />
            <Route path="/home" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/contact" component={Contact} />
            <Route path="/service" component={Services} />
        </div>
      </HashRouter> */}
    </div>
  );
};

export default template;
