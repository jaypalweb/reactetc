import React    from "react";
import template from "./Comments.jsx";
import axios from 'axios';
class Comments extends React.Component {
  constructor(){
    super();
    this.state={
      'comm':[]
    }
  }
  fnGetData(){
    axios.get('https://jsonplaceholder.typicode.com/comments')
    .then((res)=>{
      debugger;
      this.setState({
        'comm':res.data
      })
    })
    .catch((err)=>{
      debugger;
    })
  }
  render() {
    return template.call(this);
  }
}

export default Comments;
