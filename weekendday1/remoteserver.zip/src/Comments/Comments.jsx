import "./Comments.css";
import React from "react";

function template() {
  return (
    <div className="comments">
      <h1>Comments</h1>
      <input type="button" onClick={this.fnGetData.bind(this)} value="Comments" />
      {
        this.state.comm.length == 0 && <span>No comments</span>
      }
      {
        this.state.comm.map((o)=>{
            return <div>
                        <h1>{o.name}</h1>
                        <h3>{o.email}</h3>
                        <h5>{o.body}</h5>
                        <hr/>
                   </div>
        })
      }
    </div>
  );
};

export default template;
