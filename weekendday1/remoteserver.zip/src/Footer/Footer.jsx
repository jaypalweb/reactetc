import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
      <span>rights belong to me</span>
    </div>
  );
};

export default template;
