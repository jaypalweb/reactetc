import "./Menu.css";
import React from "react";
import Users from '../Users/Users';
import Posts from '../Posts/Posts';
import Comments from '../Comments/Comments';
import Login from '../Login/Login';
import {BrowserRouter,Route,Link} from 'react-router-dom';
function template() {
  return (
    <div>
        <BrowserRouter>
          <div>
              <ul className="menu">  
                 <li><Link to="/users">Users</Link></li>
                 <li><Link to="/posts">Posts</Link></li>
                 <li><Link to="/comm">Comments</Link></li>
                 <li><Link to="/login">Login</Link></li>
                
              </ul>
              <Route path="/" exact component={Login} />
              <Route path="/users" component={Users} />
              <Route path="/posts" component={Posts} />
              <Route path="/comm" component={Comments} />
              <Route path="/login/:id" component={Login} />
              
          </div>
        </BrowserRouter>
    </div>
  );
};

export default template;
