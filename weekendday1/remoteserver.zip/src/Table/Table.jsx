import "./Table.css";
import React from "react";

function template() {
  return (
    <div className="table">
        <table border="1px">
            <tr>
                {
                  this.props.h.map((v,i)=>{
                    return <th>{v}</th>
                  })
                }
            </tr>
            <tbody>
                {
                  this.props.d.map((o,i)=>{
                       return <tr>
                                  {
                                    this.props.k.map((v,i)=>{
                                      return <td>{o[v]}</td>
                                    })
                                  }
                              </tr>
                  })
                }
            </tbody>
        </table>
    </div>
  );
};

export default template;
