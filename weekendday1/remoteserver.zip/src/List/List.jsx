import "./List.css";
import React from "react";

function template() {
  return (
    <div className="list">
      <h1>{this.props.heading}</h1>
      {
        this.props.d.map((o,i)=>{
             return <ul>
                        {
                          this.props.k.map((v,i)=>{
                              return <li>{o[v]}</li>
                          })
                        }
                    </ul>
        })
      }
    </div>
  );
};

export default template;
