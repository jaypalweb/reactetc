import React from "react";
import template from "./Users.jsx";

class Users extends React.Component {
  constructor(){
    super();
    this.state={
      'headers':['ID','NAME','EMAIL','User Name'],
      'data':[],
      'keys':['id','name','email','username']
    }
  }
  componentWillMount() {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(res => {
        debugger;
        this.setState({
          'data':res
        })
      })
  }
  render() {
    return template.call(this);
  }
}

export default Users;
