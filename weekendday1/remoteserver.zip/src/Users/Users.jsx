import "./Users.css";
import React from "react";
import Table from '../Table/Table';
function template() {
  return (
    <div className="users">
      <h1>Users</h1>
      <Table h={this.state.headers} k={this.state.keys} d={this.state.data} />
    </div>
  );
};

export default template;
