import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header">
      <span>AJax calls</span>
    </div>
  );
};

export default template;
