import "./Posts.css";
import React from "react";
import List from '../List/List';
function template() {
  return (
    <div className="posts">
        <List heading="POSTS" d={this.state.data} k={this.state.keys} />
    </div>
  );
};

export default template;
