import React    from "react";
import template from "./Login.jsx";

class Login extends React.Component {
  constructor(props){
    super();
    this.state={
      'isValid':false,
      'loginInfo':{}
    }
    this.fnValidate=this.fnValidate.bind(this)
  }
  fnChage(fn,e){
    debugger;
    this.setState({
      'loginInfo':{
        ...this.state.loginInfo,
        [fn]:e.target.value
      }
    },this.fnValidate)
  }
  fnValidate(){
    debugger;
    if(this.state.loginInfo.userName  && this.state.loginInfo.password){
       this.setState({
         'isValid':true
       })

    }
  }
  render() {
    return template.call(this);
  }
}

export default Login;
