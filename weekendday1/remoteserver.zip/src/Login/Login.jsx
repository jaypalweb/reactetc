import "./Login.css";
import React from "react";

function template() {
  return (
    <div className="login">
      <h1>Login</h1>
      <input type="text" onChange={this.fnChage.bind(this,'userName')} /><input onChange={this.fnChage.bind(this,'password')} type="password"/><input type="button" value="login" onClick={this.fnLogin} disabled={!this.state.isValid}/>
    </div>
  );
};

export default template;
