import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
      <span>&copy; rights belongs to me</span>
    </div>
  );
};

export default template;
