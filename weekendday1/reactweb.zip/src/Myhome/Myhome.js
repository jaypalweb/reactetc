import React    from "react";
import template from "./Myhome.jsx";

class Myhome extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Myhome;
