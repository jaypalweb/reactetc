import "./Myhome.css";
import React from "react";

function template() {
  return (
    <div className="myhome">
      <h1>Myhome</h1>
    </div>
  );
};

export default template;
