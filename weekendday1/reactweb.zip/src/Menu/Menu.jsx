import "./Menu.css";
import React from "react";
import { HashRouter, Route } from 'react-router-dom'
import About from '../About/About';
import Contact from '../Contact/Contact';
import Service from '../Service/Service';
import Myhome from '../Myhome/Myhome';
function template() {
  return (
    <div>
      <HashRouter>
        <div>
          <div className="menu">
            <a href="#/home">Home</a>
            <a href="#/about">About</a>
            <a href="#/contact">Contact</a>
            <a href="#/service">Serivce</a>
          </div>
          <Route path="/home" component={Myhome} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/service" component={Service} />
        </div>
      </HashRouter>

    </div>
  );
};

export default template;
